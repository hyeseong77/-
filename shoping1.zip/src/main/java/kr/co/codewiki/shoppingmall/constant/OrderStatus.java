package kr.co.codewiki.shoppingmall.constant;

public enum OrderStatus {
    ORDER, CANCEL
}
