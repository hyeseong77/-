package kr.co.codewiki.shoppingmall.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
