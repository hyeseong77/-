package kr.co.codewiki.shoppingmall.constant;

public enum Role {
    USER, ADMIN // Role 값으로 USER 와 ADMIN 2개를 입력함
}
